"""
TraCI Manager

Starts, controls and closes the SUMO simulation.
"""

import traci
from simulator.config import SUMO_GUI, SUMO_CONFIG


class TraCIManager:

    def __init__(self):

        binary = "sumo-gui" if SUMO_GUI else "sumo"

        self.cmd = [
            binary,
            "-c",
            SUMO_CONFIG,
        ]

    def start(self):
        traci.start(self.cmd)

    def step(self):
        traci.simulationStep()

    def running(self):
        return traci.simulation.getMinExpectedNumber() > 0

    def close(self):
        traci.close()