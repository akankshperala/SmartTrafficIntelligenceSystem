"""
Junction Reader
"""

import traci


class JunctionReader:

    def read(self):

        junctions = []

        for junction_id in traci.junction.getIDList():

            junctions.append({

                "id": junction_id,

                "x": traci.junction.getPosition(junction_id)[0],

                "y": traci.junction.getPosition(junction_id)[1],

                "incoming": traci.junction.getIncomingEdges(junction_id),

                "outgoing": traci.junction.getOutgoingEdges(junction_id)

            })

        return junctions