"""
Vehicle Reader

Reads vehicle information from SUMO using TraCI.
"""

import traci


class VehicleReader:

    def read(self):

        vehicles = []

        vehicle_ids = traci.vehicle.getIDList()

        for vehicle_id in vehicle_ids:

            vehicles.append({

                "id": vehicle_id,

                "edge": traci.vehicle.getRoadID(vehicle_id),

                "lane": traci.vehicle.getLaneID(vehicle_id),

                "speed": traci.vehicle.getSpeed(vehicle_id),

                "waiting": traci.vehicle.getWaitingTime(vehicle_id),

                "position": traci.vehicle.getPosition(vehicle_id)

            })

        return vehicles