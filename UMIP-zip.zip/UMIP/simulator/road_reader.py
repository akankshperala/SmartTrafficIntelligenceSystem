"""
Road Reader

Reads all road information from SUMO.
"""

import traci


class RoadReader:

    def read(self):

        roads = []

        for edge in traci.edge.getIDList():

            # Ignore SUMO internal edges
            if edge.startswith(":"):
                continue

            roads.append({

                "id": edge,

                "from": traci.edge.getFromJunction(edge),

                "to": traci.edge.getToJunction(edge),

                "length": traci.lane.getLength(f"{edge}_0"),

                "speed": traci.lane.getMaxSpeed(f"{edge}_0"),

                "lanes": traci.edge.getLaneNumber(edge)

            })

        return roads