"""
Simulation

Collects simulation data from SUMO.
"""

from core.models.raw_state import RawState

from core.builders.city_builder import CityBuilder

from simulator.vehicle_reader import VehicleReader
from simulator.road_reader import RoadReader
from simulator.signal_reader import SignalReader
from simulator.junction_reader import JunctionReader

from core.builders.vehicle_builder import VehicleBuilder
from core.builders.road_builder import RoadBuilder
from core.builders.signal_builder import SignalBuilder
from core.builders.junction_builder import JunctionBuilder
from core.builders.approach_builder import ApproachBuilder
from core.builders.movement_builder import MovementBuilder


class Simulation:

    def __init__(self):

        self.vehicle_reader = VehicleReader()
        self.road_reader = RoadReader()
        self.signal_reader = SignalReader()
        self.junction_reader = JunctionReader()

        self.vehicle_builder = VehicleBuilder()
        self.road_builder = RoadBuilder()
        self.signal_builder = SignalBuilder()
        self.junction_builder = JunctionBuilder()
        self.approach_builder = ApproachBuilder()
        self.movement_builder = MovementBuilder()

        self.city_builder = CityBuilder()

        self.step = 0

    def update(self):

        raw = RawState()

        raw.vehicles = self.vehicle_builder.build(
            self.vehicle_reader.read()
        )

        raw.roads = self.road_builder.build(
            self.road_reader.read()
        )

        raw.signals = self.signal_builder.build(
            self.signal_reader.read()
        )

        raw.junctions = self.junction_builder.build(
            self.junction_reader.read()
        )

        raw.approaches = self.approach_builder.build(
            raw.roads,
            raw.vehicles,
            raw.signals
        )

        raw.movements = self.movement_builder.build(
            raw.approaches
        )

        city = self.city_builder.build(raw)

        city.current_step = self.step

        city.simulation_time = self.step

        self.step += 1

        return city