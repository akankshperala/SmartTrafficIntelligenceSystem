"""
Signal Reader

Reads all traffic signal information from SUMO.
"""

import traci


class SignalReader:

    def read(self):

        signals = []

        tls_ids = traci.trafficlight.getIDList()

        for tls_id in tls_ids:

            signals.append({

                "id": tls_id,

                "phase": traci.trafficlight.getPhase(tls_id),

                "phase_name": traci.trafficlight.getPhaseName(tls_id),

                "duration": traci.trafficlight.getPhaseDuration(tls_id),

                "controlled_lanes": traci.trafficlight.getControlledLanes(tls_id)

            })

        return signals