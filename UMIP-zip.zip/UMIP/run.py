"""
UMIP Entry Point
"""

from simulator.traci_manager import TraCIManager
from simulator.simulation import Simulation


def main():

    manager = TraCIManager()

    manager.start()

    simulation = Simulation()

    print("=" * 80)
    print("UMIP Started")
    print("=" * 80)

    while manager.running():

        manager.step()

        city = simulation.update()

        if city.current_step % 50 == 0:

            print("\n" + "=" * 80)

            print(f"Simulation Step : {city.current_step}")

            print(city)

        # Future modules will use `city`
        # Predictor.predict(city)
        # JunctionAgents.run(city)
        # Dashboard.update(city)

    manager.close()

    print("\nSimulation Finished")


if __name__ == "__main__":

    main()