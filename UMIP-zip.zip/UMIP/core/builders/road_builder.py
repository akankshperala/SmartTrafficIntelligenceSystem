"""
Road Builder
"""

from core.models.road import Road


class RoadBuilder:

    def build(self, raw_roads):

        roads = []

        for road in raw_roads:

            roads.append(

                Road(

                    id=road["id"],

                    from_junction=road["from"],

                    to_junction=road["to"],

                    length=road["length"],

                    speed_limit=road["speed"],

                    lane_count=road["lanes"]

                )

            )

        return roads