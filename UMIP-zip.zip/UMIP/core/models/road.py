"""
Road Model
"""

from dataclasses import dataclass


@dataclass
class Road:

    id: str
    from_junction: str
    to_junction: str
    length: float
    speed_limit: float
    lane_count: int

    def __str__(self):

        return (
            f"Road("
            f"id={self.id}, "
            f"from={self.from_junction}, "
            f"to={self.to_junction}, "
            f"length={self.length:.2f}, "
            f"speed={self.speed_limit:.2f}, "
            f"lanes={self.lane_count})"
        )